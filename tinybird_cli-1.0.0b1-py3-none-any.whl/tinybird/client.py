import json
import requests
import logging
import ssl
import time
from urllib.error import HTTPError
from urllib.parse import quote


try:
    from urllib2 import urlopen, Request
except:
    from urllib.request import urlopen, Request

HOST = 'https://api.tinybird.co'
LOGIN_URL = 'https://ui.tinybird.co/auth/google'


class AuthException(Exception):
    pass


class DoesNotExistException(Exception):
    pass


class TinyB(object):

    def __init__(self, token, host=HOST, version=None):
        self.token = token
        self.host = host
        self.version = version

    def _req(self, endpoint, headers=[], data=None, method=None):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        url = self.host + endpoint

        if self.token:
            url += ('&' if '?' in endpoint else '?') + 'token=' + self.token
        if self.version:
            url += ('&' if '?' in url else '?') + 'cli_version=' + quote(self.version)
        request = Request(url, method=method)

        try:
            result = urlopen(request, data=data, context=ctx)
        except HTTPError as e:
            result = e
        b = result.read()
        logging.debug("== server response ==")
        logging.debug(b)
        logging.debug("==      end        ==")
        if result.getcode() == 403:
            raise AuthException("failed auth, run `tb auth`")
        if result.getcode() == 204:
            return None
        if result.getcode() == 404:
            raise DoesNotExistException()
        if result.getcode() == 500:
            raise Exception("server error")
        if result.headers['content-type'] == 'text/plain':
            return b.decode()
        return json.loads(b)

    def tokens(self):
        return self._req("/v0/tokens")['tokens']

    def get_token_by_name(self, name):
        tokens = self.tokens()
        for tk in tokens:
            if tk['name'] == name:
                return tk
        return None

    def datasources(self, branch=None):
        ds = self._req("/v0/datasources")['datasources']
        if branch:
            ds = [x for x in ds if x['name'].startswith(branch)]
        return ds

    def datasource_file(self, ds):
        return self._req(f"/v0/datasources/{ds}.datasource")

    def pipe_file(self, pipe):
        return self._req(f"/v0/pipes/{pipe}.pipe")

    def datasource_analyze(self, url):
        return self._req("/v0/datasources?dry=true&url=" + url, data=b'')

    def datasource_analyze_file(self, data):
        return self._req("/v0/datasources?dry=true", data=data)

    def datasource_create(self, table_name, url, mode='create', status_callback=None):
        res = self._req("/v0/datasources?name=" + table_name + "&url=" + url + "&mode=" + mode, data=b'')

        if 'error' in res:
            raise Exception(res['error'])
        done = False
        while not done:
            time.sleep(1.0)
            res = self._req("/v0/jobs/" + res['id'])
            if res['status'] == 'error':
                raise Exception('There has been an error' if isinstance(res['error'], bool) else res['error'])
            done = res['status'] == 'done'
            if status_callback:
                status_callback(res)
        return res

    def datasource_append_data(self, datasource_name, f):
        url = self.host + '/v0/datasources'
        r = requests.post(
            url + '?mode=append&name=' + datasource_name,
            files={
                'csv': ('csv', f)
            },
            headers={
                'Authorization': 'Bearer ' + self.token
            }
        )
        if r.status_code != 200:
            raise Exception(r.json())
        return r.json()

    def datasource_delete(self, datasource_name):
        return self._req(f"/v0/datasources/{datasource_name}", method='DELETE', data=b'')

    def pipes(self, branch=None):
        ds = self._req("/v0/pipes")['pipes']
        if branch:
            ds = [x for x in ds if x['name'].startswith(branch)]
        return ds

    def pipe(self, pipe):
        return self._req(f"/v0/pipes/{pipe}")

    def pipe_data(self, pipe_name_or_uid, sql=None):
        if not sql:
            sql = f"SELECT * FROM {pipe_name_or_uid} LIMIT 50"
        return self._req(f"/v0/pipes/{pipe_name_or_uid}.json?q={quote(sql, safe='')}")

    def pipe_create(self, pipe_name, sql):
        return self._req(f"/v0/pipes?name={pipe_name}&sql={quote(sql, safe='')}", data=sql.encode())

    def pipe_delete(self, pipe_name):
        return self._req(f"/v0/pipes/{pipe_name}", method='DELETE', data=b'')

    def pipe_append_node(self, pipe_name_or_uid, sql):
        return self._req(f"/v0/pipes/{pipe_name_or_uid}/append", data=sql.encode())

    def pipe_set_endpoint(self, pipe_name_or_uid, published_node_uid):
        return self._req(f"/v0/pipes/{pipe_name_or_uid}/endpoint", method='PUT', data=published_node_uid.encode())

    def query(self, sql):
        return self._req(f"/v0/sql?q={quote(sql, safe='')}")
