# flake8: noqa: E501

import re
import string
from chtoolset import query as chquery


def sql_get_used_tables(sql, raising=False, default_database=''):
    try:
        return chquery.tables(sql, default_database=default_database)
    except ValueError as e:
        if raising:
            raise e
        return [(default_database, sql)]


def replace_tables(q, replacements, default_database=''):
    return chquery.replace_tables(q, replacements, default_database=default_database)


def as_subquery(sql):
    return f'({sql})'


def get_format(q):
    """
    removes FORMAT from CH sql
    >>> get_format('select * from test')
    >>> get_format('select * from test formAt JSON')
    'JSON'
    """
    FORMAT_RE = r'\s+format\s+(\w+)\s*$'
    q = q.strip()
    format = re.findall(FORMAT_RE, q, re.I)
    return format[0] if format else None


def col_name(name, backquotes=True):
    """
    >>> col_name('`test`', True)
    '`test`'
    >>> col_name('`test`', False)
    'test'
    >>> col_name('test', True)
    '`test`'
    >>> col_name('test', False)
    'test'
    >>> col_name('', True)
    ''
    >>> col_name('', False)
    ''
    """
    if not name:
        return name
    if name[0] == '`' and name[-1] == '`':
        return name if backquotes else name[1:-1]
    return f"`{name}`" if backquotes else name


def schema_to_sql_columns(schema):
    """ return an array with each column in SQL """
    columns = []
    for x in schema:
        _type = ("Nullable(%s)" if x['nullable'] else '%s') % x['type']
        c = f"{col_name(x['name'], backquotes=True)} {_type} {x['codec'] or ''}{x['default_value'] or ''}".strip()
        columns.append(c)
    return columns


def mark_error_string(s, i, context=20):
    """
    >>> mark_error_string('0123456789', 0, 4)
    '01234\\n^---'
    >>> mark_error_string('0123456789', 9, 4)
    '456789\\n     ^---'
    >>> mark_error_string('01234\\n56789', 1)
    '01234\\n ^---'
    """
    s = s.splitlines()[0]
    start = max(0, i - context - 1)
    end = min(len(s), i + context + 1)
    return s[start:end] + "\n" + (" " * (i - start)) + "^---"


def format_parse_error(table_structure, position, hint=None):
    message = f"{hint}\n" if hint else ""
    message += mark_error_string(table_structure, position)
    message += f" found '{table_structure[position]}' at position {position}"
    return message


def parse_table_structure(table_structure):  # noqa: C901
    """
    >>> parse_table_structure('c Float32, b String')
    [{'name': 'c', 'type': 'Float32', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'c'}, {'name': 'b', 'type': 'String', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'b'}]

    >>> parse_table_structure('c Nullable(Float32)')
    [{'name': 'c', 'type': 'Float32', 'codec': None, 'default_value': None, 'nullable': True, 'normalized_name': 'c'}]

    >>> parse_table_structure('`foo.bar` UInt64')
    [{'name': 'foo.bar', 'type': 'UInt64', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'foo.bar'}]

    >>> parse_table_structure('double_value Float64 CODEC(LZ4HC(2))')
    [{'name': 'double_value', 'type': 'Float64', 'codec': 'CODEC(LZ4HC(2))', 'default_value': None, 'nullable': False, 'normalized_name': 'double_value'}]
    >>> parse_table_structure('doubl/e_value Float64 CODEC(LZ4HC(2))')
    Traceback (most recent call last):
    ...
    ValueError: wrong value
    doubl/e_value Float64 CODE
         ^--- found '/' at position 5
    >>> parse_table_structure('`c` nullable(Float32)')
    [{'name': 'c', 'type': 'Float32', 'codec': None, 'default_value': None, 'nullable': True, 'normalized_name': 'c'}]
    >>> parse_table_structure('c Float32 b String')
    Traceback (most recent call last):
    ...
    ValueError: CODEC|DEFAULT|MATERIALIZED|ALIAS expected
    c Float32 b String
              ^--- found 'b' at position 10
    >>> parse_table_structure('c Int32 CODEC(Delta, LZ4)\\n')
    [{'name': 'c', 'type': 'Int32', 'codec': 'CODEC(Delta, LZ4)', 'default_value': None, 'nullable': False, 'normalized_name': 'c'}]
    >>> parse_table_structure('c  SimpleAggregateFunction(sum, Int32),\\np SimpleAggregateFunction(sum, Int32)')
    [{'name': 'c', 'type': 'SimpleAggregateFunction(sum, Int32)', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'c'}, {'name': 'p', 'type': 'SimpleAggregateFunction(sum, Int32)', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'p'}]
    >>> parse_table_structure('c Int32 CODEC(Delta, LZ4) Materialized b*2\\n')
    [{'name': 'c', 'type': 'Int32', 'codec': 'CODEC(Delta, LZ4)', 'default_value': 'Materialized b*2', 'nullable': False, 'normalized_name': 'c'}]
    >>> parse_table_structure('c Int32 CODEC(Delta, LZ4) Materialized ifNull(b*2, 0)\\n')
    [{'name': 'c', 'type': 'Int32', 'codec': 'CODEC(Delta, LZ4)', 'default_value': 'Materialized ifNull(b*2, 0)', 'nullable': False, 'normalized_name': 'c'}]
    >>> parse_table_structure('c Int32 Materialized b*2\\n')
    [{'name': 'c', 'type': 'Int32', 'codec': None, 'default_value': 'Materialized b*2', 'nullable': False, 'normalized_name': 'c'}]
    >>> parse_table_structure('c Int32 Materialized b != 1 ? b*2: pow(b, 3)\\n')
    [{'name': 'c', 'type': 'Int32', 'codec': None, 'default_value': 'Materialized b != 1 ? b*2: pow(b, 3)', 'nullable': False, 'normalized_name': 'c'}]
    >>> parse_table_structure('')
    []
    >>> parse_table_structure('`date` Date,`timezone` String,`offset` Int32')
    [{'name': 'date', 'type': 'Date', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'date'}, {'name': 'timezone', 'type': 'String', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'timezone'}, {'name': 'offset', 'type': 'Int32', 'codec': None, 'default_value': None, 'nullable': False, 'normalized_name': 'offset'}]
    """
    # ' ',^' ', ' '|','
    LSTRIP, NAME, TYPE, CODEC, DEFAULT_VALUE = 1, 2, 3, 4, 5
    # FINISH = 6
    mode = LSTRIP
    name = ''
    _type = ''
    codec = ''
    default_value = ''
    columns = []
    valid_chars = string.ascii_letters + string.digits + '._`*<>+-\''
    valid_chars_fn = valid_chars + "(), =!?:\n"
    parenthesis = 0

    def eof(i):
        return i == len(table_structure)

    for i, c in enumerate(table_structure):
        if mode == LSTRIP and c not in ' \n':
            mode = NAME
            name += c
        elif mode == NAME:
            if c in ' \n':
                mode = TYPE
            elif c not in valid_chars:
                raise ValueError(format_parse_error(
                    table_structure, i, "wrong value"))
            else:
                name += c
        elif mode == TYPE:
            if c == '(':
                parenthesis += 1
            if c == ')':
                parenthesis -= 1
            if c in ' \n' and parenthesis == 0 and _type != '':
                if _type.lower() != 'nested':
                    mode = CODEC
            elif (c in ',' or eof(i)) and parenthesis == 0:
                columns.append(dict(name=name, type=_type.strip(),
                                    codec=codec, default_value=''))
                name, _type, codec, default_value, mode = '', '', '', '', LSTRIP
            elif c not in valid_chars_fn:
                raise ValueError(format_parse_error(
                    table_structure, i, "wrong value"))
            else:
                _type += c
        elif mode == CODEC:
            if c == '(':
                parenthesis += 1
            if c == ')':
                parenthesis -= 1
            if c in ' \n' and parenthesis == 0 and codec != '':
                if codec[:5].lower() == 'codec':
                    mode = DEFAULT_VALUE
            if (c in ',' or eof(i)) and parenthesis == 0:
                if codec[:5].lower() == 'codec':
                    columns.append(dict(name=name, type=_type,
                                        codec=codec, default_value=''))
                else:
                    columns.append(dict(name=name, type=_type,
                                        codec='', default_value=codec))
                name, _type, codec, default_value, mode = '', '', '', '', LSTRIP
            elif c not in valid_chars_fn:
                raise ValueError(format_parse_error(
                    table_structure, i, "wrong value"))
            else:
                if codec == '' and c not in 'cCcmMdDaA':
                    raise ValueError(format_parse_error(
                        table_structure, i, "CODEC|DEFAULT|MATERIALIZED|ALIAS expected"))
                codec += c
        elif mode == DEFAULT_VALUE:
            if c == '(':
                parenthesis += 1
            if c == ')':
                parenthesis -= 1
            if (c in ',' or eof(i)) and parenthesis == 0:
                columns.append(dict(name=name, type=_type,
                                    codec=codec, default_value=default_value))
                name, _type, codec, default_value, mode = '', '', '', '', LSTRIP
            elif c not in valid_chars_fn:
                raise ValueError(format_parse_error(
                    table_structure, i, "wrong value"))
            else:
                if default_value == '' and c not in 'mMdDaA':
                    raise ValueError(format_parse_error(
                        table_structure, i, "DEFAULT|MATERIALIZED|ALIAS expected"))
                default_value += c

    if codec[:5].lower() != 'codec':
        default_value = codec
        codec = ''

    if name:
        columns.append(dict(name=col_name(name, backquotes=False), type=_type.strip(
        ), codec=codec.strip(), default_value=default_value))

    # normalize columns
    for column in columns:
        nullable = 'nullable' in column['type'].lower()
        column['type'] = column['type'] if not nullable else column['type'][len(
            'Nullable('):-1]  # ')'
        column['nullable'] = nullable
        column['codec'] = column['codec'] if column['codec'] else None
        column['name'] = col_name(column['name'], backquotes=False)
        column['normalized_name'] = column['name']
        column['default_value'] = column['default_value'].strip(
        ) if column['default_value'] else None

    return columns


def engine_can_be_replicated(engine):
    """
    >>> engine_can_be_replicated('MergeTree() order by tuple()')
    True
    >>> engine_can_be_replicated('JOIN(ANY, LEFT, foo)')
    False
    >>> engine_can_be_replicated('ReplicatingMergeTree() order by tuple()')
    True
    >>> engine_can_be_replicated(None)
    False
    """
    if not engine:
        return False
    return 'mergetree' in engine.lower()


def engine_replicated_to_local(engine):
    """
    >>> engine_replicated_to_local("ReplicatedMergeTree('/clickhouse/tables/{layer}-{shard}/test.foo','{replica}') order by (test)")
    'MergeTree() order by (test)'
    >>> engine_replicated_to_local("ReplicatedReplacingMergeTree('/clickhouse/tables/{layer}-{shard}/test.foo','{replica}',timestamp) order by (test)")
    'ReplacingMergeTree(timestamp) order by (test)'
    >>> engine_replicated_to_local("Join(ANY, LEFT, test)")
    'Join(ANY, LEFT, test)'
    """
    def _replace(m):
        parts = m.groups()
        s = parts[0] + "MergeTree("
        if parts[1]:
            tk = parts[1].split(',')
            if len(tk) > 2:  # remove key and {replica} part
                s += ','.join(tk[2:])
        s += ")" + parts[2]
        return s

    if 'Replicated' not in engine:
        return engine

    return re.sub(r"Replicated(.*)MergeTree\(([^\)]*)\)(.*)",
                  _replace,
                  engine.strip()
                  )


def engine_local_to_replicated(engine, database, name):
    """
    transforms a engine definition to a replicated one

    >>> engine_local_to_replicated('MergeTree() order by (test)', 'test', 'foo')
    "ReplicatedMergeTree('/clickhouse/tables/{layer}-{shard}/test.foo','{replica}') order by (test)"
    >>> engine_local_to_replicated('ReplacingMergeTree(timestamp) order by (test)', 'test', 'foo')
    "ReplicatedReplacingMergeTree('/clickhouse/tables/{layer}-{shard}/test.foo','{replica}',timestamp) order by (test)"
    """

    def _replace(m):
        parts = m.groups()
        s = "Replicated" + \
            parts[0] + "MergeTree('/clickhouse/tables/{layer}-{shard}/%s.%s','{replica}'" % (
                database, name)
        if parts[1]:
            s += "," + parts[1]
        s += ")" + parts[2]
        return s

    return re.sub(r"(.*)MergeTree\(([^\)]*)\)(.*)",
                  _replace,
                  engine.strip()
                  )


def engine_patch_replicated_engine(engine, engine_full, new_table_name):
    """
    >>> engine_patch_replicated_engine("ReplicatedMergeTree", "ReplicatedMergeTree('/clickhouse/tables/1-1/table_name', 'replica') PARTITION BY toYYYYMM(EventDate) ORDER BY (CounterID, EventDate, intHash32(UserID)) SAMPLE BY intHash32(UserID) SETTINGS index_granularity = 8192", 'table_name_staging')
    "ReplicatedMergeTree('/clickhouse/tables/1-1/table_name_staging', 'replica') PARTITION BY toYYYYMM(EventDate) ORDER BY (CounterID, EventDate, intHash32(UserID)) SAMPLE BY intHash32(UserID) SETTINGS index_granularity = 8192"
    >>> engine_patch_replicated_engine("ReplicatedMergeTree", "ReplicatedMergeTree('/clickhouse/tables/{layer}-{shard}/sales_product_rank_rt_replicated_2', '{replica}') PARTITION BY toYYYYMM(date) ORDER BY (purchase_location, sku_rank_lc, date)", 'sales_product_rank_rt_replicated_2_staging')
    "ReplicatedMergeTree('/clickhouse/tables/{layer}-{shard}/sales_product_rank_rt_replicated_2_staging', '{replica}') PARTITION BY toYYYYMM(date) ORDER BY (purchase_location, sku_rank_lc, date)"
    >>> engine_patch_replicated_engine("ReplicatedMergeTree", None, 't_000') is None
    True
    >>> engine_patch_replicated_engine("Log", "Log()", 't_000')
    'Log()'
    >>> engine_patch_replicated_engine("MergeTree", "MergeTree PARTITION BY toYYYYMM(event_date) ORDER BY (event_date, event_time) SETTINGS index_granularity = 1024", 't_000')
    'MergeTree PARTITION BY toYYYYMM(event_date) ORDER BY (event_date, event_time) SETTINGS index_granularity = 1024'
    """
    if not engine_full:
        return None
    if engine.lower().startswith('Replicated'.lower()):
        parts = re.split(
            r"(Replicated.*MergeTree\(')([^']*)('.*)", engine_full)
        paths = parts[2].split('/')
        paths[-1] = new_table_name
        zoo_path = '/'.join(paths)
        return ''.join(parts[:2] + [zoo_path] + parts[3:])
    return engine_full


if __name__ == '__main__':
    print(replace_tables(
        "select joinGet('abcd', 'test', 1)", {'abcd': 'testing'}))
