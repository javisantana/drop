
import logging
import json
import glob
import os.path
import click
import re
import pprint
from pathlib import Path
from urllib.parse import urlencode, urlparse
from collections import defaultdict
import requests
import humanfriendly
import humanfriendly.tables

from tinybird.client import TinyB, AuthException, DoesNotExistException
from tinybird.datafile import folder_push, get_name_tag_version, parse_pipe, parse_datasource, ParseException, get_project_filenames, build_graph
from tinybird import __cli__
try:
    from tinybird.__cli__ import __revision__
except:
    __revision__ = None

VERSION = f"{__cli__.__version__} (rev {__revision__})"
DEFAULT_HOST = 'https://api.tinybird.co'


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    CGREY = '\33[90m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def print_error(msg):
    click.echo(click.style(msg, reverse=False, bg='red', fg='white'))


def print_data_table(res):
    if not res['data']:
        print("No rows")
        return

    dd = []
    for d in res['data']:
        dd.append(d.values())
    print(humanfriendly.tables.format_smart_table(dd, column_names=res['data'][0].keys()))


def normalize_datasource_name(s):
    s = re.sub(r'[^0-9a-zA-Z_]', '_', s)
    if s[0] in '0123456789':
        return "c_" + s
    return s


def generate_datafile(datafile, filename, csv_data, force):
    p = Path(filename)
    base = Path('datasources')
    if not base.exists():
        base = Path()
    f = base / (normalize_datasource_name(p.stem) + ".datasource")
    if not f.exists() or force:
        open(f'{f}', 'w').write(datafile)
        print(f"** Generated {f}")
        print(f"**   => Run `tb push {f}` to create it on the server")
        print(f"**   => Add data with `tb datasource append {p.stem} {filename}`")
        if csv_data:
            # generate fixture
            if (base / 'fixtures').exists():
                f = base / 'fixtures' / (p.stem + ".csv")
                open(f, 'w').write(csv_data)
                print(f"**   => Generated fixture {f}")
    else:
        print_error(f"** {f} already exists, use --force to override")


class CatchAuthExceptions(click.Group):
    """utility class to get all the auth exceptions"""
    def __call__(self, *args, **kwargs):
        try:
            return self.main(*args, **kwargs)
        except AuthException as exc:
            print_error(exc)


@click.group(cls=CatchAuthExceptions)  # noqa: C901
@click.option('--debug/--no-debug', default=False, help="Print internal representation")
@click.option('--token', envvar='TOKEN', help="Set auth token")
@click.option('--host', envvar='TB_HOST', help="Set custom host if it's different than https://api.tinybird.co")
@click.version_option(version=VERSION)
@click.pass_context
def cli(ctx, debug, token, host):
    # ensure that ctx.obj exists and is a dict (in case `cli()` is called
    # by means other than the `if` block below
    ctx.ensure_object(dict)
    if debug:
        logging.basicConfig(level=logging.DEBUG)

    config = {}

    if ctx.invoked_subcommand == 'auth':
        config['host'] = host or DEFAULT_HOST
        ctx.obj['config'] = config
        return

    logging.debug("debug enabled")
    config_file = Path(os.getcwd()) / ".tinyb"
    try:
        config = json.loads(open(config_file).read())
    except IOError:
        valid_token = False
        if token:
            click.echo(f"** Testing TOKEN env variable")
            cl = TinyB(token, host or DEFAULT_HOST, version=VERSION)
            try:
                cl.tokens()
                valid_token = True
            except Exception as e:
                raise e
                click.echo("** => failed auth")

        if not valid_token:
            print_error(f"{config_file} does not exist, run 'tb auth' to initialize")
            token = click.prompt("Go to https://ui.tinybird.co/tokens, copy admin token and paste it", hide_input=True)
        try:
            config = {
                'token': token,
                'host': host or DEFAULT_HOST
            }
            open(config_file, 'w').write(json.dumps(config))
        except Exception:
            print_error(f"{config_file} can't be written, check write permissions on this folder")
            return
    except json.decoder.JSONDecodeError:
        print_error(config_file + " can't be loaded, remove it and run the command again")
        return

    # env token has preference over config token
    if token and config.get('token', None) is None:
        click.echo("using TOKEN env variable to auth")
        config['token'] = token
    if host:
        config['host'] = host

    ctx.obj['config'] = config
    ctx.obj['client'] = TinyB(config['token'], config.get('host', DEFAULT_HOST), version=VERSION)


def folder_init(cl, folder, generate_datasources=False):
    paths = [
        'endpoints',
        'datasources',
        'datasources/fixtures',
        'explorations',
        'pipes'
    ]
    for x in paths:
        click.echo(f"** {x} created ")
        try:
            f = Path(folder) / x
            f.mkdir()
        except FileExistsError:
            pass

    if generate_datasources:
        for filename in glob.glob('*.csv'):
            data = open(filename).read(1024 * 1024)
            meta = cl.datasource_analyze_file(data.encode())
            schema = meta['sql_schema'].replace(', ', ',\n    ')
            datafile = f"""DESCRIPTION generated from {filename}\n\nSCHEMA >\n    {schema}"""
            generate_datafile(datafile, filename, data, False)


@cli.command()
@click.option('--generate-datasources', is_flag=True, default=False, help="Generate datasources based on csv files in this folter")
@click.pass_context
def init(ctx, generate_datasources):
    """Initialize folder layout"""
    client = ctx.obj['client']
    folder_init(client, os.getcwd(), generate_datasources)


@cli.command()
@click.argument('filename', type=click.Path(exists=True))
@click.option('--debug', is_flag=True, default=False, help="Print internal representation")
def check(filename, debug):
    """Check file syntax"""
    print(f"** processing {filename}")
    try:
        if '.pipe' in filename:
            doc = parse_pipe(filename)
        else:
            doc = parse_datasource(filename)
    except ParseException as e:
        raise click.ClickException(e)

    print(f'\n{bcolors.OKGREEN + "OK" + bcolors.ENDC}')

    if debug:
        pp = pprint.PrettyPrinter()
        for x in doc.nodes:
            pp.pprint(x)


@cli.command()
@click.option('--prefix', default='', help="Use prefix for all the resources")
@click.option('--dry-run', is_flag=True, default=False, help="Run the command without creating resources on the Tinybird account or any side effect")
@click.option('--check/--no-check', is_flag=True, default=True, help="Enable/Disable output checking, enabled by default")
@click.option('--push-deps', is_flag=True, default=False, help="Push dependencies, disabled by default")
@click.option('--debug', is_flag=True, default=False, help="Print internal representation")
@click.option('--force', is_flag=True, default=False, help="Override pipes when they already exist")
@click.option('--populate', is_flag=True, default=False, help="Populate materialized nodes when pushing them")
@click.option('--fixtures', is_flag=True, default=False, help="Append fixtures to data sources")
@click.argument('filenames', type=click.Path(exists=True), nargs=-1, default=None)
@click.pass_context
def push(ctx, prefix, filenames, dry_run, check, push_deps, debug, force, populate, fixtures):
    """Push files to Tinybird
    """
    token = ctx.obj['config'].get('token')
    host = ctx.obj['config'].get('host', DEFAULT_HOST)
    folder_push(token, host, prefix, filenames, dry_run, check, push_deps, debug, force, populate=populate, upload_fixtures=fixtures)


@cli.command()  # noqa: C901
@click.option('--folder', default='.', type=click.Path(exists=True, file_okay=False), help="Folder where files will be placed")
@click.option('--match', default=None, help='Retrieve any resourcing matching the pattern. eg --match _test')
@click.option('--prefix', default=None, help="Download only resources with this prefix")
@click.option('--force', is_flag=True, default=False, help="Override existing files")
@click.pass_context
def pull(ctx, folder, match, prefix, force):
    """Retrieve latest versions for project files from Tinybird"""
    client = ctx.obj['client']
    folder_pull(client, folder, match, prefix, force)


def folder_pull(client, folder, match, tag, force):  # noqa: C901

    pattern = re.compile(match) if match else None

    def _get_latest_versions(resources):
        versions = {}
        for x in resources:
            t = get_name_tag_version(x)
            t['original_name'] = x
            if t['version'] is None:
                t['version'] = -1
            name = t['name']
            if t['tag'] == tag:
                if name in versions:
                    if versions[name]['version'] < t['version']:
                        versions[name] = t
                else:
                    versions[name] = t
        return versions

    def write_files(versions, extension, get_resource_function, file_folder=None):
        for k in versions.values():
            name = f"{k['name']}.{extension}"
            f = Path(folder)
            if file_folder:
                f = Path(folder) / file_folder
            f = f / name
            if pattern and not pattern.search(name):
                click.secho(f"[D] skipping {name}", fg='red')
                continue
            log = f"[D] writting {f}"
            if tag:
                log += f"({tag})"
            print(log)
            try:
                b = getattr(client, get_resource_function)(k['original_name'])
                if not f.exists() or force:
                    with open(f, 'w') as fd:
                        # versions are a client only thing so
                        # datafiles from the server do not contains information about versions
                        if k['version'] >= 0:
                            b = f"VERSION {k['version']}\n" + b
                        fd.write(b)
                else:
                    print("  =>  skipping, already exists")
            except Exception as e:
                print_error(e)

    remote_datasources = sorted([x['name'] for x in client.datasources()])
    versions = _get_latest_versions(remote_datasources)
    write_files(versions, 'datasource', 'datasource_file')

    remote_pipes = sorted([x['name'] for x in client.pipes()])
    versions = _get_latest_versions(remote_pipes)
    write_files(versions, 'pipe', 'pipe_file')


@cli.command()
@click.option('--no-deps', is_flag=True, default=False, help="Print only data sources with no pipes using them")
@click.option('--match', default=None, help='Retrieve any resource matching the pattern')
@click.pass_context
def dependencies(ctx, no_deps, match):
    """
    Print all data sources dependencies
    """
    cl = ctx.obj['client']
    datasources = cl.datasources()
    pipes = cl.pipes()
    pattern = re.compile(match) if match else None

    ds = defaultdict(set)
    for p in pipes:
        for node in p['nodes']:
            for t in node['dependencies']:
                ds[t].add(p['name'])

    for x in datasources:
        if not pattern or pattern.search(x['name']):
            deps = [p for p in ds[x['name']]]
            if no_deps:
                if len(deps) == 0:
                    click.secho(x['name'], fg='blue')
            else:
                click.secho(x['name'], fg='blue')
                for d in deps:
                    print(f"  - {d}")

            print("")


@cli.command()
@click.pass_context
def auth(ctx):
    """Configure auth"""
    config_file = Path(os.getcwd()) / ".tinyb"
    token = click.prompt("Go to https://ui.tinybird.co/tokens, copy admin token and paste it", hide_input=True)

    # create a client to check if it's working
    host = ctx.obj['config'].get('host', DEFAULT_HOST)
    cl = TinyB(token, host)
    try:
        cl.tokens()
    except Exception:
        print_error(f"Invalid token for {host}")
        return

    try:
        config = {
            'token': token,
            'host': host
        }
        open(config_file, 'w').write(json.dumps(config))
    except Exception:
        print_error(f"{config_file} can't be written, check write permissions on this folder")
        return

    click.echo("** Auth successful!")
    click.echo("** Configuration written to .tinyb file, consider adding it to .gitignore")


@cli.group()
@click.pass_context
def datasource(ctx):
    '''Data sources commands'''


@datasource.command(name="ls")
@click.option('--prefix', default=None, help="Show only resources with this prefix")
@click.pass_context
def datasource_ls(ctx, prefix):
    """List data sources"""
    client = ctx.obj['client']
    ds = client.datasources()
    columns = ['prefix', 'version', 'name', 'row_count', 'size', 'created at', 'updated at']
    print('\nData sources:\n')
    table = []
    for t in ds:
        stats = t.get('stats', None)
        if not stats:
            stats = t.get('statistics', {'bytes': ''})
            if not stats:
                stats = {'bytes': ''}

        tk = get_name_tag_version(t['name'])
        if prefix and tk['tag'] != prefix:
            continue
        table.append((
            tk['tag'] or '',
            tk['version'] or '',
            tk['name'],
            humanfriendly.format_number(stats.get('row_count')) if 'row_count' in stats else '-',
            humanfriendly.format_size(int(stats.get('bytes'))) if stats.get('bytes', None) else '-',
            t['created_at'][:-7],
            t['updated_at'][:-7])
        )

    print(humanfriendly.tables.format_smart_table(table, column_names=columns))
    print('\n')


@datasource.command(name="append")
@click.argument('datasource_name')
@click.argument('url')
@click.pass_context
def datasource_append(ctx, datasource_name, url):
    """Create a data source from an URL or local file"""
    client = ctx.obj['client']

    def cb(res):
        if cb.First:
            blocks_to_process = len([x for x in res['block_log'] if x['status'] == 'idle'])
            if blocks_to_process:
                cb.bar = click.progressbar(label="\N{egg} blocks", length=blocks_to_process)
                cb.bar.update(0)
                cb.First = False
                cb.blocks_to_process = blocks_to_process
        else:
            done = len([x for x in res['block_log'] if x['status'] == 'done'])
            if done * 2 > cb.blocks_to_process:
                cb.bar.label = "\N{hatching chick} blocks"
            cb.bar.update(done - cb.prev_done)
            cb.prev_done = done
            # \N{hatching chick}
            # \N{ront-facing baby chick}
    cb.First = True
    cb.prev_done = 0

    try:
        click.secho("\N{egg} starting import process", fg='blue')
        parsed = urlparse(url)
        if parsed.scheme in ('http', 'https'):
            res = client.datasource_create(datasource_name, url, mode='append', status_callback=cb)
        else:
            res = client.datasource_append_data(datasource_name, open(url, 'rb'))
        # os.system('setterm -cursor on')  # recover blinking cursor
        click.secho("\n\N{front-facing baby chick} done", fg='blue')
        print(f" ** {res['datasource']['name']} created, append data with tb datasource {res['datasource']['name']} append file.csv")
    except Exception as e:
        print_error(e)


@datasource.command(name='analyze')
@click.argument('url')
@click.pass_context
def datasource_analyze(ctx, url):
    '''Analyze a URL before creating a new data source'''
    def _table(title, columns, data):
        row_format = "{:<25}" * len(columns)
        print('\n' + bcolors.BOLD + title + bcolors.ENDC + '\n')
        print(bcolors.OKBLUE + row_format.format(*columns) + bcolors.ENDC)
        for t in data:
            print(row_format.format(*t))

    client = ctx.obj['client']
    analysis = client.datasource_analyze(url)

    columns = ('name', 'type', 'nullable')
    _table('columns', columns, [(t['name'], t['type'], 'true' if t['nullable'] else 'false') for t in analysis['schema']])

    print('\n' + bcolors.BOLD + 'schema sql' + bcolors.ENDC + '\n')
    print(analysis['sql_schema'])

    _table('dialect', ('name', 'value'), list(analysis['dialect'].items()))


@datasource.command(name="rm")
@click.argument('datasource_name')
@click.option('--yes', is_flag=True, default=False, help="Do not ask for confirmation")
@click.pass_context
def datasource_delete(ctx, datasource_name, yes):
    """Delete a data source"""
    client = ctx.obj['client']
    if yes or click.confirm(f"Do you want to remove \"{datasource_name}\"? Once deleted, it can't be recovered"):
        try:
            client.datasource_delete(datasource_name)
        except DoesNotExistException:
            raise click.ClickException(f'Data source "{datasource_name}" does no exist')
        print(f'\nDeleted data source: "{datasource_name}".\n')


@datasource.command(name="generate", short_help="Generates a data source file based on a sample CSV file from local disk or url")
@click.argument('filenames', nargs=-1, default=None)
@click.option('--force', is_flag=True, default=False, help="Override existing files")
@click.pass_context
def generate_datasource(ctx, filenames, force):
    """Generate a data source file based on a sample CSV file from local disk or url"""
    cl = ctx.obj['client']

    for filename in filenames:
        data = None
        parsed = urlparse(filename)
        if parsed.scheme in ('http', 'https'):
            meta = cl.datasource_analyze(filename)
        else:
            data = open(filename).read(1024 * 1024)
            meta = cl.datasource_analyze_file(data.encode())
        schema = meta['sql_schema'].replace(', ', ',\n    ')
        datafile = f"""DESCRIPTION generated from {filename}\n\nSCHEMA >\n    {schema}"""
        generate_datafile(datafile, filename, data, force)


@cli.command()
@click.argument('query')
@click.pass_context
def sql(ctx, query):
    """Run SQL query over data sources and pipes"""
    client = ctx.obj['client']
    res = client.query(f'SELECT * FROM ({query}) FORMAT JSON')
    if 'error' in res:
        print_error(res['error'])
        return
    stats = res['statistics']
    print(f"\nQuery took {stats['elapsed']} seconds, read {humanfriendly.format_number(stats['rows_read'])} rows // {humanfriendly.format_size(stats['bytes_read'])}\n")
    if len(res['data']):
        dd = []
        for d in res['data']:
            dd.append(d.values())
        print(humanfriendly.tables.format_smart_table(dd, column_names=res['data'][0].keys()))
    else:
        print('** No rows')


@cli.group()
@click.pass_context
def pipe(ctx):
    '''Pipes commands'''


@pipe.command(name="generate", short_help="Generates a pipe file based on a sql query")
@click.argument('name')
@click.argument('query')
@click.option('--force', is_flag=True, default=False, help="Override existing files")
@click.pass_context
def generate_pipe(ctx, name, query, force):
    pipefile = f"""
NODE endpoint
DESCRIPTION >
    Generated from the command line
SQL >
    {query}

    """
    base = Path('endpoints')
    if not base.exists():
        base = Path()
    f = base / (f"{name}.pipe")
    if not f.exists() or force:
        open(f'{f}', 'w').write(pipefile)
        print(f"** Generated {f}")
        print(f"**   => Run `tb push {f}` to create it on the server")
    else:
        print_error(f"** {f} already exists, use --force to override")


@pipe.command(name="ls")
@click.option('--prefix', default=None, help="Show only resources with this prefix")
@click.pass_context
def pipe_ls(ctx, prefix):
    """List pipes"""
    client = ctx.obj['client']
    ds = client.pipes()
    columns = ['prefix', 'version', 'name', 'published date', 'nodes']
    print('\nPipes\n')
    table = []
    for t in ds:
        tk = get_name_tag_version(t['name'])
        if prefix and tk['tag'] != prefix:
            continue
        table.append((
            tk['tag'] or '',
            tk['version'] or '',
            tk['name'],
            t['created_at'][:-7],
            len(t['nodes'])
        ))

    print(humanfriendly.tables.format_smart_table(table, column_names=columns))

    print('\n')


@pipe.command(name="new")
@click.argument('pipe_name')
@click.argument('sql')
@click.pass_context
def pipe_create(ctx, pipe_name, sql):
    """Create a new pipe"""
    client = ctx.obj['client']
    host = ctx.obj['config'].get('host', DEFAULT_HOST)
    res = client.pipe_create(pipe_name, sql)

    print("** New pipe created")
    print(f"** Node id: {res['nodes'][0]['id']}")
    print(f"** Set node as endpoint with: \"tb pipe set_endpoint {pipe_name} {res['nodes'][0]['id']}\"\n")
    print(f'The pipe API endpoint: "{host}/v0/pipes/{pipe_name}"')


@pipe.command(name="append")
@click.argument('pipe_name_or_uid')
@click.argument('sql')
@click.pass_context
def pipe_append_node(ctx, pipe_name_or_uid, sql):
    """Append a node to a pipe"""
    client = ctx.obj['client']
    res = client.pipe_append_node(pipe_name_or_uid, sql)
    print(f"\nNew node \"{res['id']}\"\n")


@pipe.command(name="set_endpoint")
@click.argument('pipe_name_or_id')
@click.argument('node_uid', default=None, required=False)
@click.pass_context
def pipe_published_node(ctx, pipe_name_or_id, node_uid=None):
    """Change the published node of a pipe"""
    client = ctx.obj['client']
    host = ctx.obj['config'].get('host', DEFAULT_HOST)

    try:
        pipe = client.pipe(pipe_name_or_id)
        if not node_uid:
            node = pipe['nodes'][-1]['name']
            print(f'** Using last node "{node}" as endpoint')
        else:
            node = node_uid

        res = client.pipe_set_endpoint(pipe_name_or_id, node)
        print(f"** Published node: \"{res['id']}\"\n")
        print(f'** The pipe endpoint is: "{host}/v0/pipes/{pipe_name_or_id}.json"')
    except DoesNotExistException:
        raise click.ClickException(f'"{pipe_name_or_id}" pipe does no exist')


@pipe.command(name="rm")
@click.argument('pipe_name_or_id')
@click.option('--yes', is_flag=True, default=False, help="Do not ask for confirmation")
@click.pass_context
def pipe_delete(ctx, pipe_name_or_id, yes):
    """Delete a pipe"""

    client = ctx.obj['client']
    if yes or click.confirm(f"Do you want to remove the pipe \"{pipe_name_or_id}\"?"):
        try:
            client.pipe_delete(pipe_name_or_id)
        except DoesNotExistException:
            raise click.ClickException(f'"{pipe_name_or_id}" pipe does no exist')
        print(f'\nDeleted pipe "{pipe_name_or_id}".\n')


@pipe.command(name="token_read")
@click.argument('pipe_name')
@click.pass_context
def pipe_token_read(ctx, pipe_name):
    """Retrieve a token to read a pipe"""
    client = ctx.obj['client']

    try:
        client.pipe_file(pipe_name)
    except DoesNotExistException:
        raise click.ClickException(f'"{pipe_name}" pipe does no exist')

    tokens = client.tokens()
    token = None

    for t in tokens:
        for scope in t['scopes']:
            if scope['type'] == 'PIPES:READ' and scope['resource'] == pipe_name:
                token = t['token']
    if token:
        print(token)
    else:
        print(f'There\'s no read token for pipe "{pipe_name}"')


@pipe.command(name="data", context_settings=dict(
    allow_extra_args=True,
    ignore_unknown_options=True,
))
@click.argument('pipe')
@click.option('--query', default=None, help="Run SQL over pipe results")
@click.option('--format', default=None, help="Return format (CSV, JSON)")
@click.pass_context
def print_pipe(ctx, pipe, query, format):
    """Print data returned by a pipe"""
    token = ctx.obj['config'].get('token')
    host = ctx.obj['config'].get('host', DEFAULT_HOST)
    params = {ctx.args[i][2:]: ctx.args[i + 1] for i in range(0, len(ctx.args), 2)}
    headers = {'Authorization': f'Bearer {token}'}
    req_format = 'json' if not format else format.lower()
    if query:
        params['q'] = query
    params['cli_version'] = VERSION
    r = requests.get(f"{host}/v0/pipes/{pipe}.{req_format}?{urlencode(params)}", headers=headers)
    if r.status_code != 200:
        print(f"Error {r.json()['error']}")
        return
    if not format:
        res = r.json()
        stats = res['statistics']
        print(f'\nPipe: "{bcolors.OKGREEN + pipe + bcolors.ENDC}"')
        print(f"Stats: took {stats['elapsed']} seconds, read {stats['rows_read']} rows and {stats['bytes_read']} bytes\n")
        print_data_table(res)
        print('\n')
    else:
        print(r.content.decode())


@cli.command()
@click.argument('prefix')
@click.option('--yes', is_flag=True, default=False, help="Do not ask for confirmation")
@click.option('--dry-run', is_flag=True, default=False, help="Run the command without removing anything")
@click.pass_context
def drop_prefix(ctx, prefix, yes, dry_run):
    """drop all the resources inside a project with prefix
    This command is dangerous because it removes everything, use with care
    """

    filenames = get_project_filenames(os.getcwd())
    resources, _ = build_graph(filenames, process_dependencies=True)
    names = [r['resource_name'] for r in resources.values()]

    client = ctx.obj['client']
    ds = client.datasources()
    for t in ds:
        tk = get_name_tag_version(t['name'])
        if tk['tag'] == prefix and tk['name'] in names:
            if not dry_run:
                print(f"** Removing data source {t['name']}")
                client.datasource_delete(t['name'])
            else:
                print(f"[DRY-RUN] Removing data source {t['name']}")

    ds = client.pipes()
    for t in ds:
        tk = get_name_tag_version(t['name'])
        if tk['tag'] == prefix and tk['name'] in names:
            if not dry_run:
                print(f"** Removing pipe {t['name']}")
                client.pipe_delete(t['name'])
            else:
                print(f"[DRY-RUN] Removing pipe {t['name']}")


if __name__ == '__main__':
    cli({})
