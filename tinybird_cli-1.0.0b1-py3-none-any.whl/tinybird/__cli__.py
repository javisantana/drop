
__name__ = 'tinybird-cli'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '1.0.0b1'
__revision__ = '962b0e18'
